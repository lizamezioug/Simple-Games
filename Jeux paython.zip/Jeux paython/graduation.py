import pygame
import random
import math
from pygame import mixer

pygame.init()

# création de la fenetre
screen = pygame.display.set_mode((1000, 600))
# background image
background = pygame.image.load("back.png")

# titre du jeu et le logo
pygame.display.set_caption("GRADUATION GAME")
icon = pygame.image.load("graduated.png")
pygame.display.set_icon(icon)

# start
game_state = "not_started"

# girl
playerImg = pygame.image.load("girl.png")
playerX = 450
playerY = 450
playerX_change = 0
playerY_change = 0

# cap
capImg = []
capX = []
capY = []
capX_change = []
capY_change = []
num_of_cap = 8
for i in range(num_of_cap):
    capImg.append(pygame.image.load("graduate-cap.png"))
    capX.append(random.randint(0, 950))
    capY.append(random.randint(50, 100))
    capX_change.append(1)
    capY_change.append(20)

# boule
bouleImg = pygame.image.load("boule.png")
bouleX = 0
bouleY = 450
bouleX_change = 0
bouleY_change = 2
boule_state = "ready"  # ready: on ne peut pas voir la boule sur l'ecrant ;fire: la boule bouge

# score
score_value = 0
font = pygame.font.Font('SuperMario256.ttf', 40)
textX = 400
textY = 20

# game over
over_font = pygame.font.Font('SuperMario256.ttf', 64)

# graduated
grad_font = pygame.font.Font('SuperMario256.ttf', 64)


def show_start_button():
    start_button_text = font.render("Start", True, (255, 255, 255))
    screen.blit(start_button_text, (450, 250))


def graduation_text():
    grad_text = grad_font.render("Graduated !! ", True, (255, 255, 255))
    screen.blit(grad_text, (320, 250))


def show_score(X, Y):
    score = font.render("Score : " + str(score_value), True, (255, 255, 255))
    screen.blit(score, (X, Y))


def gameover_text():
    over_text = over_font.render("Game Over ", True, (255, 255, 255))
    screen.blit(over_text, (320, 250))


def player(X, Y):
    screen.blit(playerImg, (X, Y))


def cap(X, Y, i):
    screen.blit(capImg[i], (X, Y))


def fire_boule(X, Y):
    global boule_state
    boule_state = "fire"
    screen.blit(bouleImg, (X + 50, Y + 10))


def iscollision(capX, capY, bouleX, bouleY):
    distance = math.sqrt((math.pow(capX - bouleX, 2)) + (math.pow(capY - bouleY, 2)))
    if distance < 30:
        return True
    else:
        return False


# boucle pour avoir la fenetre et la fermer (fixation de l'image)
running = True
while running:

    screen.fill((222, 222, 222))  # RGB red, green, blue la couleur de l'arrière-plan  elle est entre 0 et 255
    # background image
    screen.blit(background, (0, 0))

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        # Événements de souris pour détecter le clic
        if event.type == pygame.MOUSEBUTTONDOWN and game_state == "not_started":
            mixer.music.load("background.wav")
            mixer.music.play(-1)
            mouse_x, mouse_y = pygame.mouse.get_pos()
            if 450 <= mouse_x <= 550 and 250 <= mouse_y <= 300:
                game_state = "playing"

        # vérification des touches
        if event.type == pygame.KEYDOWN:  # l'appuie sur la touche
            if event.key == pygame.K_LEFT:
                playerX_change = -2
            if event.key == pygame.K_RIGHT:
                playerX_change = 2
            if event.key == pygame.K_SPACE:
                if boule_state == "ready":
                    boule_sound = mixer.Sound("laser.wav")
                    boule_sound.play()
                    bouleX = playerX
                    fire_boule(bouleX, bouleY)

        if event.type == pygame.KEYUP:  # relâchement de la touche
            if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT:
                playerX_change = 0

    # Vérification du score
    if score_value >= 2024:
        for j in range(num_of_cap):
            capY[j] = 5000  # déplacer toutes les capes en dehors de la fenetre
        graduation_text()
        pygame.display.update()
        pygame.time.delay(3000)  # Attendre 3 secondes
        pygame.quit()
        quit()

    # mouvement du joueur
    playerX += playerX_change
    # limitation par rapport au bordure de la fenetre
    if playerX <= 0:
        playerX = 0
    if playerX >= 900:
        playerX = 900

    # Logique du jeu basée sur l'état du jeu
    if game_state == "not_started":
        show_start_button()
    elif game_state == "playing":
        # mouvement de la cap
        for i in range(num_of_cap):
            # game over
            if capY[i] > 400:
                for j in range(num_of_cap):
                    capY[j] = 5000  # deplacer toutes les capes en dehors de la fenetre
                gameover_text()
                break

            capX[i] += capX_change[i]
            if capX[i] <= 0:
                capX_change[i] = 1
                capY[i] += capY_change[i]
            elif capX[i] >= 950:
                capX_change[i] = -1
                capY[i] += capY_change[i]

            # collision
            collision = iscollision(capX[i], capY[i], bouleX, bouleY)
            if collision:
                explosion_sound = mixer.Sound("explosion.wav")
                explosion_sound.play()
                bouleY = 450
                boule_state = "ready"
                score_value += 253
                print(score_value)
                capX[i] = random.randint(0, 950)
                capY[i] = random.randint(50, 200)

            cap(capX[i], capY[i], i)

    # mouvement de la boule
    if bouleY <= 0:
        bouleY = 450
        boule_state = "ready"
    if boule_state == "fire":
        fire_boule(bouleX, bouleY)
        bouleY -= bouleY_change

    player(playerX, playerY)
    show_score(textX, textY)
    pygame.display.update()
