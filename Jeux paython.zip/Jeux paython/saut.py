import pygame

pygame.init()
win_width, win_height = 1000, 500
win = pygame.display.set_mode((win_width, win_height), pygame.RESIZABLE)
pygame.display.set_caption("JUMP GAME")
icon = pygame.image.load("jump.png")
pygame.display.set_icon(icon)

player_image = pygame.image.load("jump.png")
player_rect = player_image.get_rect()
player_rect.midbottom = (win_width // 2, win_height*0.9)  # Position initiale en bas et au milieu

# background image
background = pygame.image.load("jeu.png")
background = pygame.transform.scale2x(background)
background = pygame.transform.scale(background, (win_width, win_height)).convert()

velx = 10
vely = 10
jump = False

run = True
while run:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
        elif event.type == pygame.VIDEORESIZE:
            win_width, win_height = event.w, event.h
            win = pygame.display.set_mode((win_width, win_height), pygame.RESIZABLE)

            # Redimensionner le background avec la nouvelle taille de la fenêtre
            background = pygame.image.load("jeu.png")
            background = pygame.transform.scale2x(background)
            background = pygame.transform.scale(background, (win_width, win_height)).convert()

            # Ajuster les coordonnées du joueur après redimensionnement
            player_rect.midbottom = (win_width // 2, win_height-100)

    # mouvement
    userInput = pygame.key.get_pressed()
    if userInput[pygame.K_LEFT] and player_rect.left > 0:
        player_rect.x -= velx
    if userInput[pygame.K_RIGHT] and player_rect.right < win_width:
        player_rect.x += velx
    if userInput[pygame.K_UP] and player_rect.top > 0:
        player_rect.y -= vely
    if userInput[pygame.K_DOWN] and player_rect.bottom < win_height-100:
        player_rect.y += vely
    if jump is False and userInput[pygame.K_SPACE]:
        jump = True
    if jump:
        player_rect.y -= vely * 6
        vely -= 1
        if vely < -10:
            jump = False
            vely = 10

    # Effacer la fenêtre
    win.fill((0, 0, 0))

    # Afficher le joueur et le background
    win.blit(background, (0, 0))
    win.blit(player_image, player_rect)

    pygame.display.flip()  # Forcer la mise à jour complète de l'écran

    pygame.time.delay(30)

pygame.quit()
