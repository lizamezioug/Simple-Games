import random

def guess_the_number():
    lower_limit = 1
    upper_limit = 100
    secret_number = random.randint(lower_limit, upper_limit)
    max_attempts = 10
    attempts = 0

    print(f"Devine le nombre entre {lower_limit} et {upper_limit}.")

    while attempts < max_attempts:
        guess = int(input("Entre ton estimation : "))
        attempts += 1

        if guess < secret_number:
            print("C'est plus grand.")
        elif guess > secret_number:
            print("C'est plus petit.")
        else:
            print(f"Bravo ! Tu as deviné le nombre {secret_number} en {attempts} essais.")
            break

    if guess != secret_number:
        print(f"Dommage ! Le nombre était {secret_number}.")

guess_the_number()
