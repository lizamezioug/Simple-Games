import pygame
pygame.init()

# création de la fenetre
screen = pygame.display.set_mode((1000, 600))
    # titre du jeu et le logo
pygame.display.set_caption("JUMP GAME")
icon = pygame.image.load("jump.png")
pygame.display.set_icon(icon)



    # joueur
playerImg = pygame.image.load("jump.png")
playerX=470
playerY=250
playerX_change =0
playerY_change = 0



def player(X,Y):
    screen.blit(playerImg, (X, Y))

#boucle pour avoir la fenetre et la fermer (fixation de l'image)
running = True
while running:

    screen.fill((50, 50, 50))# RGB red,green,blue la couleur de l'arriére plan  elle est entre 0 et 255
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

            # vérification des touches
        if event.type == pygame.KEYDOWN:  # l'appuie sur la touche
            if event.key == pygame.K_LEFT:
               playerX_change = -0.1
            if event.key == pygame.K_RIGHT:
               playerX_change = 0.1
            if event.key == pygame.K_UP:
                playerY_change = 0.1
            if event.key == pygame.K_DOWN:
                playerY_change = -0.1
        if event.type == pygame.KEYUP:  # relachement de la touche
           if event.key == pygame.K_UP or event.key == pygame.K_DOWN:
              playerY_change = 0
           if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT:
              playerX_change = 0

    # limitation par rapport au bordure de la fenetre
    if playerX <= 0:
        playerX = 0
    if playerX >= 930:
        playerX = 930
    if playerY <= 0:
        playerY = 0
    if playerY >= 530:
        playerY = 530


    # enregistrement des infos du joueur
    playerY -= playerY_change
    playerX += playerX_change


    player(playerX, playerY)
    pygame.display.update()



